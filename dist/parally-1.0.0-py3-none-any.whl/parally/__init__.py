"""Parally is a Python library for distributed computing
over a socket connection.
"""

from .server import * # noqa
from .client import * # noqa
